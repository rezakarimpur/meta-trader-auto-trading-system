# MQL5-Python-Backtesting
MQL5 based backtesting using python


Trading strategies send the buy, sell or hold signal to MQL5
Based on the signal Metatrader 5 perform the trading

How to run the Strategies:
1. open main_decisionmaker.py and import the trading strategy which is intended to run
2. Update the strategy and the signal line
3. Start the backtesting in Metatrader 5
4. Copy the python files along with the strategy folder(trading_strategies) into Metatrader 5 testing/files folder
5. copy other python files - main_decisionmaker.py, output.py and actionWriter.py
6. run main_decisionmaker.py

Explained in this video https://www.youtube.com/watch?v=ovKgQdiQsHE&t=764s
